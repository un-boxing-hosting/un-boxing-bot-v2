module.exports = { 
    name: 'website', 
    description: "Link to tools", 
    execute(message, args){ 
   
   message.channel.send('https://webflow.com/design/mtm-bots');
    

} 

}