module.exports = { 
    name: 'when', 
    description: "creation date!", 
    execute(message, args){ 
   
   message.channel.send('I was made 3/6/2021 by MeTheMystical he has made me to help his friends viewers and more, He also hopes that you enjoy me helping you!');
   
    }

}