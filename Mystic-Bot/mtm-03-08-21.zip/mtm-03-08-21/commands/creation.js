module.exports = {
    name: 'creation',
    description: "made",
    execute(message, args){
        message.channel.send('i was made 3/6/2021 by MeTheMystical he has made me to help his friends viewers and more, He also hopes that you enjoy me helping you!');
    }
}