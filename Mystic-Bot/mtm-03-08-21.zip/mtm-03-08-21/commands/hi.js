module.exports = {
    name: 'hi',
    description: "hello",
    execute(message, args){
        message.channel.send('hello I am MTM im a discord bot of course but why dose that matter im here to help you to get help or list of commands do %help');
    }
}