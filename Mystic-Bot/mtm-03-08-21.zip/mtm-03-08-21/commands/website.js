module.exports = {
    name: 'website',
    description: "webpage",
    execute(message, args){
        message.channel.send('https://methemystical.wixsite.com/my-site');
    }
}