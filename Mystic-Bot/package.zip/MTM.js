const Discord = require('discord.js'); 

const client = new Discord.client(); 

Discord.Client.once('ready', () => { 
    console.log('MTM is online!');

});









































client.login('ODE3NDk3NTYxNDY0MDQ1NTg4.YEKX7w.ZeHFrUwWAvE2Vp98DGn_oH6jyzU');